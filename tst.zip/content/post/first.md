---
title: "vddde"
description: "spf13-vim is a cross platform distribution of vim plugins and resources for Vim."
tags: [ ".vimrc", "plugins", "spf13-vim", "vim" ]
lastmod: 2015-12-23
date: "2015-04-06"
categories:
  - "Development"
  - "VIM"
---

滴滴CTO张博在滴滴内网论坛帖子截图

“以前没有，以后也永远不会有。”针对网传“大数据杀熟”，滴滴出行CTO（首席技术官）张博予以否认并称，这是公司价值观的底线。

3月23日，有网友在微博爆料称，不同系统、不同级别的用户，在使用滴滴软件叫车时，会出现路程相同却存在价格差异的情况，该网友称“滴滴利用大数据杀熟”。

一时间，网民纷纷在社交平台晒出“实测”结果，有的显示价格一致，有的则存在差异。

